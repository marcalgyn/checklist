module.exports = {
  vetCst: [
    {
      chave: 'ICMSSN101',
      valor: 101
    },
    {
      chave: 'ICMSSN102',
      valor: 102
    },
    {
      chave: 'ICMSSN103',
      valor: 103
    },
    {
      chave: 'ICMSSN201',
      valor: 201
    },
    {
      chave: 'ICMSSN202',
      valor: 202
    },
    {
      chave: 'ICMSSN203',
      valor: 203
    },
    {
      chave: 'ICMSSN300',
      valor: 300
    },
    {
      chave: 'ICMSSN400',
      valor: 400
    },
    {
      chave: 'ICMSSN500',
      valor: 500
    },
    {
      chave: 'ICMSSN900',
      valor: 900
    },
    {
      chave: 'ICMS00',
      valor: 0
    },
    {
      chave: 'ICMS10',
      valor: 10
    },
    {
      chave: 'ICMS20',
      valor: 20
    },
    {
      chave: 'ICMS30',
      valor: 30
    },
    {
      chave: 'ICMS40',
      valor: 40
    },
    {
      chave: 'ICMS41',
      valor: 41
    },
    {
      chave: 'ICMS50',
      valor: 50
    },
    {
      chave: 'ICMS51',
      valor: 51
    },
    {
      chave: 'ICMS60',
      valor: 60
    },
    {
      chave: 'ICMS70',
      valor: 70
    },
    {
      chave: 'ICMS90',
      valor: 90
    },
  ]
}

